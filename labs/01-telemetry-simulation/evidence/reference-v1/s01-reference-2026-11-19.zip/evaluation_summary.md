# S01 — avaliação de cenários sintéticos

- Identificador da execução: `s01-ci-reference`
- Política de avaliação: versão 1
- Escopo: conformidade de software, não acurácia de um classificador de causas.

| Cenário | Intervenção conhecida | Recebidos | Inválidos | Lacunas | Duplicados | Fora de ordem | Veredito |
|---|---|---:|---:|---:|---:|---:|---|
| baseline | nenhuma | 5 | 0 | 0 | 0 | 0 | conformant |
| drop | omit_before_receiver | 4 | 0 | 1 | 0 | 0 | conformant |
| duplicate | repeat_frame | 6 | 0 | 0 | 1 | 0 | conformant |
| reorder | swap_frames | 5 | 0 | 1 | 0 | 1 | conformant |
| corrupt | flip_payload_bit | 5 | 1 | 1 | 0 | 0 | conformant |

## Interpretação

- **conformant:** relatório consistente e resultados previstos observados; não prova reconhecimento da causa.
- **deviation:** contagens ou eventos divergentes da política predefinida.
- **inconsistent:** metadados, contagens internas, ou hashes declarados não conferem.
- No cenário `reorder`, há lacuna observada mas nenhum quadro foi omitido no gerador.
- No cenário `drop`, a omissão é conhecida somente pelo gerador; o receptor registra uma lacuna.
- Este avaliador compara hashes declarados; para recomputá-los a partir de bytes arquivados, execute verify_evidence.py.
- Não estimar sensibilidade, precisão, recall ou taxa de acerto com estes casos didáticos.
